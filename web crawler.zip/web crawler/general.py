import os


# Each website is a separate project (folder)
def create_project_dir(directory):
    if not os.path.exists(directory):
        print('Creating directory ' + directory)
        os.makedirs(directory)


# Create queue and crawled files (if not created)
def create_data_files(project_name, base_url): #provide starting point to 
    #file path for queue
    queue = os.path.join(project_name , '/queue.txt')
    #file path that are already crawled 
    crawled = os.path.join(project_name,'/crawled.txt')
    # file path exist ? if not create a new one
    if not os.path.isfile(queue):
        #whenever we launch the program it has one url in the waiting list. here base url is provides the starting point for the program
        write_file(queue, base_url)
        #storing the already crawled files. here 2nd parameter is empty becasue if we provide any link then program will consider it as already crawled and will not loook for it
    if not os.path.isfile(crawled):
        write_file(crawled, '')


# Create a new file
def write_file(path, data):
    #w stands for writing
    with open(path, 'w') as f:
        f.write(data)


# Add data onto an existing file
def append_to_file(path, data):
    # here a indicates the appending
    with open(path, 'a') as file:
        file.write(data + '\n')


#Delete the contents of a file. in this case we will create a file of same name which will overwrite the old file with the same name and basically deletes all the data.
#much more efficient way to clean the data instead of cleaning it one by one.
def delete_file_contents(path):
    open(path, 'w').close()


# Read a file and convert each line to set items. to remove the duplicate links.
def file_to_set(file_name):
    results = set()
    #here rt is indicates the read text 
    with open(file_name, 'rt') as f:
        for line in f:
            #deleting the new line character
            results.add(line.replace('\n', ''))
    return results


# Iterate through a set, each item will be a line in a file
# (links to save in - > file_name)
def set_to_file(links, file_name):
    with open(file_name,"w") as f:
        for l in sorted(links):
            f.write(l+"\n")
